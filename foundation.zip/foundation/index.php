<?php
	include 'header.php';
	?>
	

	<!-- Hero Section end -->
	<section class="hero-section">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="hs-text">
						<h2></h2>
						
						
					</div>
				</div>
				
			</div>
		</div>
		<div class="hero-slider owl-carousel">
			
			<div class="hs-item set-bg" data-setbg="img/hero-slider/3.jpg"></div>
		</div>
	</section>
	<!-- Hero Section end -->

	<!-- Why Section end -->
	<section class="why-section spad">
		<div class="container">
			<div class="text-center mb-5 pb-4">
				<h2>Who We Are</h2>
			</div>
			<div class="row">
				<div class="col-md-4">
					<div class="icon-box-item">
						<div class="ib-icon">
							
						</div>
						<div class="ib-text">
						
							<p>Foundation Site</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="icon-box-item">
						<div class="ib-icon">
							
						</div>
						<div class="ib-text">
							
							<p>	Free
				</div>
				<div class="col-md-4">
					<div class="icon-box-item">
						<div class="ib-icon">
							
						</div>
						<div class="ib-text">
						
							<p> Hope you will find it useful	</div>
				</div>
			</div>
			<div class="text-center pt-3">
				<a href="apply.php" class="site-btn sb-big">Apply Now</a>
			</div>
		</div>
	</section>
	<!-- Why Section end -->



	<?php
	include 'footer.php';
	?>