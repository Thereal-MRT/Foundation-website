<?php
	include 'header.php';
	?>

	<!-- Header Section end -->

	<!-- Page top Section end -->

	<!-- Page top Section end -->

	<!-- Contact Section end -->
	<section class="page-top-section set-bg" data-setbg="img/page-top-bg/1.jpg">
		<div class="container">
			<h2>Eligible</h2>
			<nav class="site-breadcrumb">
				<a class="sb-item" href="#">Home</a>
				<span class="sb-item active">Eligible</span>
			</nav>
		</div>
	</section>
	<section class="contact-section spad">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="contact-text">
						<h2>Who is Eligible</h2>
						<p>Eligibility</p><div class="contact-text">
						<h2>Free to use </h2>	
						<p> State governments
     </p>	
	<div class="contact-text">
						<h2>Education organizations</h2>
						<p>     </p>	
	<div class="contact-text">
						
	<h2> Public Housing Organizations</h2>

   <p> Public housing authorities <br/>
    Indian housing authorities </p>


<h2>Non-profit Organizations</h2>

   


<h2> For-Profit Organizations </h2>

   <p> Organizations other than small businesses </p>


<h2> Small Businesses </h2>



<h2> Individuals </h2>





<p> Before applying, Read term and condition. </p>
					</div>
				</div>
				
			</div>
			
		</div>
	</section>
	<!-- Contact Section end -->

	<?php
	include 'footer.php';
	?>