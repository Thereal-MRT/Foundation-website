

	<!-- Footer Section -->
	<footer class="footer-section">
		<div class="container">
			<a href="index.html" class="footer-logo">
				<img src="" alt="">
            </a>
         

          <!-- Start Google Map -->
          
			<div class="row">
				<div class="col-lg-3 col-sm-6">
					<div class="footer-widget">
						<h2>Address</h2>
						<p> Your Adrress</p>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="footer-widget">
						<h2>Contact</h2>
						<p> Your Phone Number <br/>
contact@foundation.com</p>
					</div>
				</div>
				
				<div class="col-lg-3 col-sm-6">
					<div class="footer-widget">
						<h2>Working Hours</h2>
						<p> Our Customer Department is Available 24Hours All day
</p>
					</div>
				</div>
				
				
	</footer>
	<!-- Footer Section end -->
	
	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.slicknav.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<script src="js/main.js"></script>

	</body>
</html>
