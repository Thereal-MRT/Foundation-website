<?php
	include 'header.php';
	?>
	<!--r Section end -->

	<!-- Page top Section end -->
	<section class="page-top-section set-bg" data-setbg="img/page-top-bg/1.jpg">
		<div class="container">
			<h2>About us</h2>
			<nav class="site-breadcrumb">
				<a class="sb-item" href="#">Home</a>
				<span class="sb-item active">About us</span>
			</nav>
		</div>
	</section>
	<!-- Page top Section end -->

	<!-- About Section end -->
	<section class="about-section spad">
		<div class="container">
			<div class="row">
				<div class="col-lg-5">
					<img src="img/about-img.jpg" alt="">
				</div>
				<div class="col-lg-7">
					<div class="about-text">
						<h2>About Foundation Website</h2>
						<p> Free, easy.</p>
						
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- About Section end -->

	<?php
	include 'footer.php';
	?>