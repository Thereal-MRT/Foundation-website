<?php
	include 'header.php';
	include 'dbconnection.php';
	?>
  <section class="page-top-section set-bg" data-setbg="img/page-top-bg/1.jpg">
		<div class="container">
			<h2>Beneficiary</h2>
			<nav class="site-breadcrumb">
				<a class="sb-item" href="#">Home</a>
				<span class="sb-item active">Beneficiary List</span>
			</nav>
		</div>
	</section>
<section class="about-section spad">
		<div class="container">
			<div class="row">
				
				<div class="col-lg-7">
					<div class="about-text">
						<h2>Benefit Grant List</h2>

						<table class="table">
  <thead>
    <tr>
      <th scope="col">S/N0.</th>
      <th scope="col">Name</th>
      <th scope="col">State and Country</th>
      <th scope="col">Amount ($) </th>
      <th scope="col">Status</th>
      
    </tr>
  </thead>
  <?php
$ret=mysqli_query($con,"select *from tblname");
$cnt=1;
while ($row=mysqli_fetch_array($ret)) {

?>
  <tbody>
  <tr>
                  <td><?php echo $cnt;?></td>
            
                  <td><?php  echo $row['name'];?></td>
                  <td><?php  echo $row['state'];?></td>
                  <td><?php  echo $row['amount'];?></td>
                  <td><?php  echo $row['status'];?></td>
                
                  
                <?php 
$cnt=$cnt+1;
}?>
                                    </table>
    
					</div>
				</div>
			</div>
		</div>
	</section>
                <?php
	include 'footer.php';
	?>