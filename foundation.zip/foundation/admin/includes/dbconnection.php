<?php
$con=mysqli_connect("localhost", "ffassist_root", "facebook6116", "ffassist_cvmsdb");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
