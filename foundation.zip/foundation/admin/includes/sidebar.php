<aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
        
                   <h3>ADMIN PANEL</h3>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li>
                            <a href="dashboard.php"  style="color: blue">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                        </li>

     <li>
                            <a href="add_name.php"  style="color: blue">
                                <i class="fa fa-user"></i>Add Name to Homepage</a>
                        </li>
                        <li>
                            <a href="manage_name.php"  style="color: blue">
                                <i class="fa fa-users"></i>Manage Name on Homepage</a>
                        </li>
   <li>
                            <a href="check-name.php"  style="color: blue">
                                <i class="fa fa-users"></i>Check list of Applicant</a>
                        </li>

                        
                      <li>
                            <a href="bwdates-reports.php"  style="color: blue">
                                <i class="fas fa-copy"></i>Check Applicant by Dates</a>
                        </li>  
                       
                    </ul>
                </nav>
            </div>
        </aside>