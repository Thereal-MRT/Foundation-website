<div class="row">
                            <div class="col-md-12">
                            <ul class="list-unstyled navbar__list">
                        <li>
                            <a href="dashboard.php"  style="color: blue">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                        </li>

     <li>
                            <a href="add_name.php"  style="color: blue">
                                <i class="fa fa-user"></i>Add Name to Homepage</a>
                        </li>
                        <li>
                            <a href="manage_name.php"  style="color: blue">
                                <i class="fa fa-users"></i>Manage Name on Homepage</a>
                        </li>
   <li>
                            <a href="check-name.php"  style="color: blue">
                                <i class="fa fa-users"></i>Check list of Applicant</a>
                        </li>

                        
                      <li>
                            <a href="bwdates-reports.php"  style="color: blue">
                                <i class="fas fa-copy"></i>Check Applicant by Dates</a>
                        </li>  
                       
                    </ul>
                            </div>
                        </div>